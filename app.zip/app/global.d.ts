declare global {
    interface Window {
        Tawk_API?: Record<string, any>;
    }
}

export { };
